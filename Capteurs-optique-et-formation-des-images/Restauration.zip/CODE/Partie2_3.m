% ========================================================================
%                      M1 S14 - TP 2 MATLAB
%      Restauration interactive d'images par transformee de Fourier
%           Partie 2.3 - Correction d'une interference sinusoidale
% ========================================================================

% Ajouter le chemin vers les fonctions auxiliaires
addpath('./utils')
close all, clear all

% Lecture et affichage de l'image
im = imread('louvreSin.png');
figure, imshow(im);


% ----------- COMPLETER --------------------
