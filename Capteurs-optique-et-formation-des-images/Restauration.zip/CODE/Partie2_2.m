% ========================================================================
%                      M1 S14 - TP 2 MATLAB
%      Restauration interactive d'images par transformee de Fourier
%                 Partie 2.2 - Correccion d'un bouge
% ========================================================================

% Ajouter le chemin vers les fonctions auxiliaires
addpath('./utils')
close all, clear all, clc

% Lecture et affichage de l'image
g = imread('louvreBouge.png');
figure, imshow(g);

% ----------- COMPLETER --------------------

% Transformee de Fourier de l'image d'entree
fg = fftshift(fft2(g));

fgc = log(1+abs(fg));
fgcs=sum(fgc);
figure, imshow(fgc,[]);

% Estimation de H
[vf,uf] = size(fg);
T = 1;
d = 1/19;
u = (-uf/2:uf/2-1)*(1/1);


fh =  ones(vf,1) * ( T * exp(-j*pi*u*d) .* sin(pi*u*d) ./ (pi*u*d) );
figure, imshow(log(1+abs(fh)) ,[])

% Estimation de F en frequence (corrigee)

ff = fg ./ fh ;
figure, imshow(log(1+abs(ff)) ,[])

% Recuperer l'image corrigee

f = uint8( real( ifft2( ifftshift( ff ) ) ) );
figure, imshow(f);


figure,
subplot(2,2,1), imshow(g); title('Image originale')
subplot(2,2,2), imshow(fgc,[]); title('TF')
subplot(2,2,3), imshow(log(1+abs(fh)) ,[]); title('Filtre estim�')
subplot(2,2,4), imshow(log(1+abs(ff)) ,[]); title('TF filtr�')
