% ========================================================================
%                      M1 S14 - TP 2 MATLAB
%      Restauration interactive d'images par transformee de Fourier
%                 Partie 2.2 - Correccion d'un bouge
% ========================================================================

%KABOU Abdeldjalil


% Ajouter le chemin vers les fonctions auxiliaires
addpath('./utils')
close all, clear all 

% Lecture et affichage de l'image
im = imread('louvreBouge.png');
figure, imshow(im);title('Image originale');

% ----------- COMPLETER --------------------

% Transformee de Fourier de l'image d'entree

TF_g = fftshift(fft2(im));
TF_gc = log(1+abs(TF_g));
TF_gcs = sum(TF_gc);
figure, imshow(TF_gc,[]); title('La TF');

% Estimation de H

[vf,uf] = size(TF_g);
T = 1;
d = 1/19;
u = (-uf/2:uf/2-1)*(1/1);
fh =  ones(vf,1) * ( T * exp(-j*pi*u*d) .* sin(pi*u*d) ./ (pi*u*d) );
figure, imshow(log(1+abs(fh)) ,[]),title('Estimation');

% Estimation de F en frequence (corrigee)

ff = TF_g ./ fh ;
figure, imshow(log(1+abs(ff)) ,[]),title('Estimation de F en frequence (corrigee)');

% Recuperer l'image corrigee

f = uint8( real( ifft2( ifftshift( ff ) ) ) );
figure, imshow(f); title('Image corrigee')
