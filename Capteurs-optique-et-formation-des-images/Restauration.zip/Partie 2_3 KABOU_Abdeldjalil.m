% ========================================================================
%                      M1 S14 - TP 2 MATLAB
%      Restauration interactive d'images par transformee de Fourier
%           Partie 2.3 - Correction d'une interference sinusoidale
% ========================================================================

%KABOU Abdeldjalil

% Ajouter le chemin vers les fonctions auxiliaires
addpath('./utils')
close all, clear all

% Lecture et affichage de l'image
im = imread('louvreSin.png');
figure, imshow(im);title('Image originale');


% ----------- COMPLETER --------------------

% Transformee de Fourier de l'image d'entree

TF_g = fftshift(fft2(im));
TF_gc = log(1+abs(TF_g));
TF_gcs = sum(TF_gc);
figure, imshow(TF_gc,[]); title('La TF');

%filtre proposé
[M, N] = size(im);
[u, v] = meshgrid(1:N, 1:M);
% Coordonnées des pics (j'ai mis des coordonnées pas tellement précis)
x1 = 240; y1 = 170;
x2 = 340; y2 = 230;
D0 = 10;               % Rayon du filtre
% Création du masque passe-bande
D1 = sqrt((u - x1).^2 + (v - y1).^2);
D2 = sqrt((u - x2).^2 + (v - y2).^2);
filter = ones(M, N);
% Suppression des fréquences parasites
filter(D1 < D0) = 0;
filter(D2 < D0) = 0;

% Afficher le filtre
figure, imshow(filter, []), title('Filtre proposé "passe-bande"');

% Appliquer le filtre sur le spectre
F_filtre = TF_g .* filter;
figure, imshow(log(1 + abs(F_filtre)), []), title('La TF après filtrage');

% Transformée de Fourier inverse
F_inverse = ifftshift(F_filtre);
I_restaure = real(ifft2(F_inverse)); 
figure, imshow(uint8(I_restaure)), title('Image restaurée');
