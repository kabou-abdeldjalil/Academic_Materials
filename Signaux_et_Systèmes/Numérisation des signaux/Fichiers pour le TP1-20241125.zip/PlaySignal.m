function PlaySignal(x,Fs,S,AAF)
% PlaySignal Play sound
%
%    PlaySignal(x,Fs) sends the signal in vector x with sample frequency
%    of Fs Hertz to audio device.
%
%    PlaySignal(x,Fs,S) sends the S time subsampled signal in vector x 
%
%    PlaySignal(x,Fs,S,1) sends the S time subsampled signal in vector x 
%    filtered with an Anti-Aliasing filter to audio device. 

% H. Carfantan 30/11/2011

  if nargin<3,
      S = 1; 	% Default subsampling factor
      AAF = 0; 	% Default : non Anti-Aliasing Filter
  elseif nargin<4,
      AAF = 0;	% Default : non Anti-Aliasing Filter
  end
  x = x(:)'; % line vector
  
  % Synthèse d'un filtre passe-bas (Anti-repliement et reconstruction)
  if S>1,
    Wp =.9/S; Rp = 1; Ws =1/S; Rs = 60;
    [N, Wn] = cheb2ord(Wp, Ws, Rp, Rs);
    [b, a] = cheby2(N,Rs, Ws);
  end
  if ((AAF==1) & (S>1)), % Filtering with an Anti-Aliasing Filter
      fprintf('listening to signal subsampled with a factor %d with AAF filtering\n',S)
      x = filter(b,a,x); x = x/max(x)*.99;
  else
      fprintf('listening to signal subsampled with a factor %d without AAF filtering\n',S)
  end

if 0
% Ecoute à différentes fréquences d'échantillonnage : à éviter
% Peut poser des problème car les cartes sons sont prévues pour fonctionner
% à certaines fréquences d'échantillonnage seulement
% En écoutant à la fréquence d'échantillonnage la plus proche compatible
% avec la carte on, cela provoque des accélérations ou ralentissement du signal

% Subsampling  
  signal = x(1:S:end);
  
% Play signal
  if ispc % Windows version of Matlab
	 wavplay(signal,Fs/S,'sync'); 
  else % Linux version of Matlab
     p = audioplayer(signal,Fs/S); 
     playblocking(p);
     clear p
  end
  
else
% Ecoute à la même fréquence d'échantillonnage que le signal original
% par sous-échantillonnage et filtrage passe-bas
% Subsampling
  y = zeros(size(x));
  y(1:S:end) = x(1:S:end);
  if S>1,
      y = filter(b,a,y)*S;
  end
% Play signal
   if ispc % Windows version of Matlab
 	 wavplay(y,Fs,'sync'); 
   else % Linux version of Matlab
      p = audioplayer(y,Fs); 
      playblocking(p);
      clear p
   end
end




