% Shahram Hosseini
% novembre 2016
function xq=quantif(x,N)
b=min(x);
a=max(x)-b;
y=(x-b)/a;
pas=(2^N-1);
yq=round(y*pas)/pas;
xq=a*yq+b;




